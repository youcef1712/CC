import { Component, computed, effect, input } from '@angular/core';
import { LeafletModule } from '@bluehalo/ngx-leaflet';
import { latLng, LatLng, LatLngTuple, Layer, Marker, tileLayer } from 'leaflet';
import { getLayerFromGeoJSON, getLeafletMarkerFromCoords } from '../../data/geometrie';
import { CommuneCarto } from '../../data/data.carto';

/**
 * Interface Typescript représentant les données
 * utiles liées à la carte d'une commune.
 */
interface CommuneState extends CommuneCarto {
  readonly layers: Layer[]; // Le tableau doit être mutable d'après la spécification de la bibliothèque ngx-leaflet
  readonly options: {
    readonly zoom: 10;
    readonly minZoom: 10;
    readonly maxZoom: 10;
    readonly zoomControl: false;
    readonly attributionControl: false;
    readonly dragging: false;
    readonly center: LatLngTuple;
  }
}

@Component({
  selector: 'app-commune',
  imports: [
    LeafletModule
  ],
  templateUrl: './commune.component.html',
  styleUrl: './commune.component.scss'
})
export class CommuneComponent {  
  private readonly baseLayer = tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 18, attribution: '...' });

  public readonly communeCarto = input.required<CommuneCarto>();
  public readonly couleur = input<string>("#FF0000");

  private readonly _marker = computed<Marker>( () => getLeafletMarkerFromCoords([this.communeCarto().mairie[0], this.communeCarto().mairie[1]]) );
  private readonly _contour = computed<Layer>( () => getLayerFromGeoJSON(this.communeCarto().geometry, this.couleur()) );

  protected readonly state = computed<CommuneState>( () => ({
    ...this.communeCarto(),
    layers: [
      this.baseLayer,
      this._contour(),
      this._marker()
    ],
    options: {
      zoom: 10,
      minZoom: 10,
      maxZoom: 10,
      zoomControl: false,
      attributionControl: false,
      dragging: false,
      center: this.communeCarto().centre
    }
  }) )

  protected readonly center = computed( () => latLng(this.state().options.center));
}
