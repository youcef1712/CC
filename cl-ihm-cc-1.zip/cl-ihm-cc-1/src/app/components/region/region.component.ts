import { Component, input, model, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RegionCarto } from '../../data/data.carto';

@Component({
  selector: 'app-region',
  imports: [
    FormsModule
  ],
  templateUrl: './region.component.html',
  styleUrl: './region.component.scss'
})
export class RegionComponent {
  public readonly regionCarto = input.required<RegionCarto>();
  public readonly couleurs = model<readonly string[]>([]);

  protected readonly couleurUtilisateur = signal<string>("");

  protected updateCouleur(couleur: string, index: number) {
    [...this.couleurs()][index] = couleur;
    //this.couleurs.set()
    console.log(couleur);
    console.log("aaa");
    
    
  }
}

